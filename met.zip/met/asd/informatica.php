<?php include("template/cabecera.php");?>


<div class="jumbotron">
    <h1 class="display-4">INFORMATICA</h1>
    <p class="lead">Bienvenido a la Carrera de Ingeniería Informática</p>

<p  class="lead">Con los conocimientos en Programación, Redes, Bases de Datos entre otras el egresado podrá Aplicar sus conocimientos
en la solución de problemas en el área de informática como crear,administrar redes
de comunicación, instalación y mantenimiento para la operación de equipos de computo, diseñar, 
desarrollar e implementar Bases de Datos para la gestión de la información. </p>
 
<div class="col-md-3">
<div class="card">
<img class="card-img-top" src="css/tecnm.png" alt=""></img>   

 </div>
 
 
   
 </div>  
 </div>
</div>
<?php include("template/pie.php"); ?>
