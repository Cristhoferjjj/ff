<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>The Squad </title>

<link rel="stylesheet" href="./css/bootstrap.min.css"/>

</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <ul class="nav navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="index.php">INICIO</a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="productos.php">MENU</a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href=""></a>
        </li>

    </ul>
</nav>

<div class="container">
<br/>
    <div class="row">


<div class="jumbotron">
    <h1 class="display-2">BIENVENIDO AL METABUSCADOR</h1>
    <p class="lead-6">*TE AYUDAREMOS A ENCONTRAR TU MEJOR OPCION PARA EL FUTURO*</p>
    <hr class="display">
    <p class="display-6"> Puedes consultar nuestras redes sociales:</p>
    
    <p>FACEBOOK: https://www.facebook.com/groups/estudiantesitiz3/ </p>
    
    <p>WHATSAPP: 5532035590</p>
    
    <p>INSTAGRAM: comunidaditi3</p>
    
    <a  class="btn btn-primary btn-lg" href="nosotros.php"  role="button"  >CONOCENOS</a>

   <div class="col-md-6"> 
           <br/><br/><br/><br/><br/><br/>
           <div class="card">
               <div class="card-header">
                   REGISTRATE
                </div>
                <div class="card-body">

                 <form method="POST">

                 <div class = "form-group">
                 <label >Nombre Completo:</label>
                 <input type="text" class="form-control" name="usuario" placeholder="Ingresa tu Nombre Completo">
                 </div>
                 
                 <div class = "form-group">
                 <label >Numero Telefonico:</label>
                 <input type="text" class="form-control" name="usuario" placeholder="Ingresa tu Numero Telefonico">
                 </div>

                 <div class="form-group">
                 <label >Correo:</label>
                 <input type="password" class="form-control" name="contraseña" placeholder="Ingresa tu Correo">
                 </div>
                 <button type="submit" class="btn btn-primary">Registrar</button>
                


                 </form>

                  
                  

               </div>
              
           </div>
               
           
    </div>

  
</div>
<img src="css/meta.jpg" class="img-fluid" alt=""




</body>
</html>
